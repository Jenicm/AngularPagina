export const environment = {
  production: true,
  config: {
    apiKey: "AIzaSyAOkdPa0ziPsD72qZLunV041N2vUCmZaig",
    authDomain: "angularpagina.firebaseapp.com",
    databaseURL: "https://angularpagina.firebaseio.com",
    projectId: "angularpagina",
    storageBucket: "angularpagina.appspot.com",
    messagingSenderId: "707967489655"
  }
};
