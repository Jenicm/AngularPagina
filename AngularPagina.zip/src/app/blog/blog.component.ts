import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AngularFireDatabase } from 'angularfire2/database';


@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  blog: Observable<any[]>;
  constructor(private http: HttpClient, private db: AngularFireDatabase) { }

  ngOnInit() {
    this.blog = this.getBlog('/blogs');
    console.log(this.blog);
  }

  getBlog(listPath): Observable<any[]> {
    return this.db.list(listPath).valueChanges();
  }
}
