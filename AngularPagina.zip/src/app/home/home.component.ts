import { Component, OnInit } from '@angular/core';

import { CookieService } from 'angular2-cookie/core';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private _cookieService:CookieService, private localSt:LocalStorageService, private sessionSt:SessionStorageService) { }

  ngOnInit() {
  }

  channelName = 'CodeSpace';
 
  //COOKIES
  setCookies() {
    this._cookieService.put("test", "testing cookie");
  }

  getCookies() {
   alert(this._cookieService.get("test"));
  }

  delCookies() {
    this._cookieService.remove("test");
  }

  //LOCAL STORAGE
  setLocalStorage() {
    this.localSt.store("userName", "Rosa");
  }

  getLocalStorage() {
   alert(this.localSt.retrieve("userName"));
  }

  delLocalStorage() {
    this.localSt.clear("boundValue");
  }

  //LOCAL STORAGE
  setSessionStorage() {
    this.sessionSt.store("logged-in", "user");
  }

  getSessionStorage() {
   alert(this.sessionSt.retrieve("logged-in"));
  }

  delSessionStorage() {
    this.sessionSt.clear("logged-in");
  }
}
