import { Component, OnInit, ViewEncapsulation  } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule }   from '@angular/forms';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { Contacto } from './shared/contacto.model';
import { ContactoService } from './shared/contacto.service';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ContactoComponent implements OnInit {
  contacto: Contacto = new Contacto();


  constructor(private http: HttpClient, private router: Router, private contactoService: ContactoService) { }

  ngOnInit() {
    this.contacto = new Contacto();
  }
  
  setContacto(contacto: Contacto) {
    this.contactoService.createCustomer(this.contacto);
    this.contacto = new Contacto();
  }
}