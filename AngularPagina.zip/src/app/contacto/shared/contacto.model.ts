export class Contacto {
    mail : string;
    fecha : string;
    comentario : string;
}